import { useState } from 'react';
import '../styles.css';

function CakeCard({ cake, addToCart }) {
  const [showPopup, setShowPopup] = useState(false);

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  return (
    <div className="cake-card">
      <img src={cake.imageUrl} alt={cake.name} className="cake-image" />
      <h3>{cake.name}</h3>
      <p>{cake.description}</p>
      <p>${cake.price.toFixed(2)}</p>

      <button className="view-btn" onClick={togglePopup}>View</button>
      <button className="add-to-cart-btn" onClick={() => addToCart(cake)}>Add to Cart</button>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <span className="close-btn" onClick={togglePopup}>X</span>
            <h2>{cake.name}</h2>
            <img src={cake.imageUrl} alt={cake.name} className="popup-image" />
            <p>{cake.description}</p>
            <p>${cake.price.toFixed(2)}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default CakeCard;
