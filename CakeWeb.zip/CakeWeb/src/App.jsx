import { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CakeCard from './components/CakeCard';
import Cart from './components/Cart';
import Navbar from './components/Navbar';
import cakeData from './details.json';
import './styles.css';

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (cake) => {
    setCart([...cart, cake]);
  };

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={
            <div className="cake-container">
              {cakeData.map((cake) => (
                <CakeCard key={cake.id} cake={cake} addToCart={addToCart} />
              ))}
            </div>
          }
        />
        <Route path="/cart" element={<Cart cartItems={cart} />} />
      </Routes>
    </Router>
  );
}

export default App;
